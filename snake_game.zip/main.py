
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.properties import NumericProperty, ReferenceListProperty, ObjectProperty, ListProperty
from kivy.vector import Vector
from kivy.clock import Clock
from kivy.core.window import Window
import random

class SnakePart(Widget):
    pass

class Food(Widget):
    pass

class SnakeGame(Widget):
    snake = ListProperty([])
    direction_x = NumericProperty(0)
    direction_y = NumericProperty(1)
    direction = ReferenceListProperty(direction_x, direction_y)
    food = ObjectProperty(None)
    score = NumericProperty(0)
    game_over = False
    
    def __init__(self, **kwargs):
        super(SnakeGame, self).__init__(**kwargs)
        self.start_game()
    
    def start_game(self):
        for part in self.snake:
            self.remove_widget(part)
        
        self.snake = []
        self.score = 0
        self.game_over = False
        self.direction = (0, 1)
        
        head = SnakePart()
        head.pos = (self.center_x - 10, self.center_y - 10)
        head.size = (20, 20)
        self.add_widget(head)
        self.snake.append(head)
        
        if self.food:
            self.remove_widget(self.food)
        self.spawn_food()
        
        Clock.unschedule(self.update)
        Clock.schedule_interval(self.update, 0.1)
    
    def spawn_food(self):
        self.food = Food()
        
        while True:
            x = random.randint(0, self.width - 20)
            y = random.randint(0, self.height - 20)
            x = (x // 20) * 20
            y = (y // 20) * 20
            
            collision = False
            for part in self.snake:
                if Vector(x, y).distance(part.pos) < 10:
                    collision = True
                    break
            
            if not collision:
                break
        
        self.food.pos = (x, y)
        self.food.size = (20, 20)
        self.add_widget(self.food)
    
    def update(self, dt):
        if self.game_over:
            return
        
        head = self.snake[0]
        new_head = SnakePart()
        new_head.size = head.size
        
        new_x = head.x + self.direction_x * 20
        new_y = head.y + self.direction_y * 20
        
        if (new_x < 0 or new_x > self.width - 20 or 
            new_y < 0 or new_y > self.height - 20):
            self.end_game()
            return
        
        new_head.pos = (new_x, new_y)
        
        for part in self.snake[1:]:
            if Vector(new_head.pos).distance(part.pos) < 10:
                self.end_game()
                return
        
        self.add_widget(new_head)
        self.snake.insert(0, new_head)
        
        if Vector(new_head.pos).distance(self.food.pos) < 15:
            self.score += 10
            self.spawn_food()
        else:
            tail = self.snake.pop()
            self.remove_widget(tail)
    
    def end_game(self):
        self.game_over = True
        Clock.unschedule(self.update)
    
    def on_touch_down(self, touch):
        if self.game_over:
            self.start_game()
            return True
        
        head = self.snake[0]
        dx = touch.x - head.center_x
        dy = touch.y - head.center_y
        
        if abs(dx) > abs(dy):
            if dx > 0 and self.direction_x != -1:
                self.direction = (1, 0)
            elif dx < 0 and self.direction_x != 1:
                self.direction = (-1, 0)
        else:
            if dy > 0 and self.direction_y != -1:
                self.direction = (0, 1)
            elif dy < 0 and self.direction_y != 1:
                self.direction = (0, -1)
        
        return True

class SnakeApp(App):
    def build(self):
        return SnakeGame()

if __name__ == '__main__':
    SnakeApp().run()
